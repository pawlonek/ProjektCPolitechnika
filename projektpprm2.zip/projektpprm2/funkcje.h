void testchsum();

void wypisywanie(struct node *);

void wpisywanie(struct node *);

void wpisywanie2(struct node *);

void usun(struct node *, int);

void zmien(struct node *);

void zapisdopliku(struct node *);

void bubbleSort(struct node *);

void swap(struct node *a, struct node *);

void bubbleSortMark(struct node *);

void bubbleSortName(struct node *);

void odczyt(struct node *);
