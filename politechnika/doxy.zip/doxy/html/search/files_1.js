var searchData=
[
  ['magazyn_2ec',['magazyn.c',['../magazyn_8c.html',1,'']]],
  ['magazyn_2eh',['magazyn.h',['../magazyn_8h.html',1,'']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]]
];
