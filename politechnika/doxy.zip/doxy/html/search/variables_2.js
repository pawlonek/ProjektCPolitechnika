var searchData=
[
  ['mark',['mark',['../structnode.html#a29e4cceb1cfe4649dfe576defe5558e9',1,'node']]]
];
