var searchData=
[
  ['id',['id',['../structnmag.html#a7441ef0865bcb3db9b8064dd7375c1ea',1,'nmag']]]
];
