var searchData=
[
  ['t',['t',['../magazyn_8c.html#ae8f9b4c713ae5a9256b1b270eb2fe603',1,'magazyn.c']]],
  ['t1',['t1',['../magazyn_8c.html#ad07a5f7505a45b9a13fe306c305f7624',1,'magazyn.c']]],
  ['testchsum',['testchsum',['../funkcje_8c.html#ab0769fe34aa2c8d49889357f408a48b3',1,'testchsum():&#160;funkcje.c'],['../funkcje_8h.html#ab0769fe34aa2c8d49889357f408a48b3',1,'testchsum():&#160;funkcje.c']]]
];
