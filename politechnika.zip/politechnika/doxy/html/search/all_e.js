var searchData=
[
  ['zapisdopliku',['zapisdopliku',['../funkcje_8c.html#a6c419df1d5c3a6f4f362390027980dec',1,'zapisdopliku(struct node *gg):&#160;funkcje.c'],['../funkcje_8h.html#a6c419df1d5c3a6f4f362390027980dec',1,'zapisdopliku(struct node *gg):&#160;funkcje.c']]],
  ['zmien',['zmien',['../funkcje_8c.html#a28ce7156a52e320cc1fb13aa99c5ac01',1,'zmien(struct node *tt):&#160;funkcje.c'],['../funkcje_8h.html#a28ce7156a52e320cc1fb13aa99c5ac01',1,'zmien(struct node *tt):&#160;funkcje.c']]]
];
