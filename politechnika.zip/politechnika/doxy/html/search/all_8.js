var searchData=
[
  ['prev',['prev',['../structnmag.html#ab3dc0bf1aadd4900b6a15b5a9d84ef97',1,'nmag']]]
];
