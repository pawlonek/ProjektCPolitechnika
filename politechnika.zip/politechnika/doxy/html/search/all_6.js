var searchData=
[
  ['name',['name',['../structnode.html#af5b0b0f3f9bc648835ad6dc65d4f9a9f',1,'node::name()'],['../structnmag.html#af5b0b0f3f9bc648835ad6dc65d4f9a9f',1,'nmag::name()']]],
  ['next',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]],
  ['nmag',['nmag',['../structnmag.html',1,'']]],
  ['node',['node',['../structnode.html',1,'']]],
  ['nodus',['NODUS',['../funkcje_8c.html#a9ccb1f555cb9a30cea2656500bda3d1b',1,'funkcje.c']]]
];
