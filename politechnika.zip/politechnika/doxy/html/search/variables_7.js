var searchData=
[
  ['w',['w',['../magazyn_8c.html#acdc71fd2b9d3057b2f878291c5527606',1,'magazyn.c']]],
  ['w1',['w1',['../magazyn_8c.html#a49aa02d659a36969425c6968f63288fc',1,'magazyn.c']]]
];
