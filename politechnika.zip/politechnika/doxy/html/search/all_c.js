var searchData=
[
  ['usun',['usun',['../funkcje_8c.html#a8aac29f742f3dac25f9282c7ddd2c87d',1,'usun(struct node *gc, int psUsun):&#160;funkcje.c'],['../funkcje_8h.html#a8aac29f742f3dac25f9282c7ddd2c87d',1,'usun(struct node *gc, int psUsun):&#160;funkcje.c']]]
];
