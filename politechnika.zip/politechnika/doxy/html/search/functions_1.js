var searchData=
[
  ['magshow',['magshow',['../magazyn_8c.html#ac5c6a7337610b813ae5111e449f6b386',1,'magshow(int id_wyswietl):&#160;magazyn.c'],['../magazyn_8h.html#a226da9c57b5eb76c938dbff7900a6adc',1,'magshow(int id):&#160;magazyn.c']]],
  ['magsprawdz',['magsprawdz',['../magazyn_8c.html#a3a460747317c043565980edaa02c73b4',1,'magsprawdz(int id_dane):&#160;magazyn.c'],['../magazyn_8h.html#a3a460747317c043565980edaa02c73b4',1,'magsprawdz(int id_dane):&#160;magazyn.c']]],
  ['main',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]]
];
