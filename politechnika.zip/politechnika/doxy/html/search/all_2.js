var searchData=
[
  ['funkcje_2ec',['funkcje.c',['../funkcje_8c.html',1,'']]],
  ['funkcje_2eh',['funkcje.h',['../funkcje_8h.html',1,'']]]
];
