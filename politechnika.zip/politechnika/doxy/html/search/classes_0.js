var searchData=
[
  ['nmag',['nmag',['../structnmag.html',1,'']]],
  ['node',['node',['../structnode.html',1,'']]]
];
