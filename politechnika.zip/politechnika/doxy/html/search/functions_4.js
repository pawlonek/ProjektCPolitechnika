var searchData=
[
  ['testchsum',['testchsum',['../funkcje_8c.html#ab0769fe34aa2c8d49889357f408a48b3',1,'testchsum():&#160;funkcje.c'],['../funkcje_8h.html#ab0769fe34aa2c8d49889357f408a48b3',1,'testchsum():&#160;funkcje.c']]]
];
