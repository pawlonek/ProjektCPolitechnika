var searchData=
[
  ['wpisywanie',['wpisywanie',['../funkcje_8c.html#ae99ad3ea2f3f737f510a6d9121f7d3e7',1,'wpisywanie(struct node *g):&#160;funkcje.c'],['../funkcje_8h.html#ae99ad3ea2f3f737f510a6d9121f7d3e7',1,'wpisywanie(struct node *g):&#160;funkcje.c']]],
  ['wpisywanie2',['wpisywanie2',['../funkcje_8c.html#afc3558a03a5364cba5305c0f47477196',1,'wpisywanie2(struct node *g):&#160;funkcje.c'],['../funkcje_8h.html#afc3558a03a5364cba5305c0f47477196',1,'wpisywanie2(struct node *g):&#160;funkcje.c']]],
  ['wypisywanie',['wypisywanie',['../funkcje_8c.html#a73dc5a2caab2d4b1caad9c83139cfeeb',1,'wypisywanie(struct node *start):&#160;funkcje.c'],['../funkcje_8h.html#a73dc5a2caab2d4b1caad9c83139cfeeb',1,'wypisywanie(struct node *start):&#160;funkcje.c']]]
];
