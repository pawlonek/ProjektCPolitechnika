var searchData=
[
  ['odczyt',['odczyt',['../funkcje_8c.html#a597d8f3c32ad18692b555989d2fd606f',1,'odczyt(struct node *ww):&#160;funkcje.c'],['../funkcje_8h.html#a597d8f3c32ad18692b555989d2fd606f',1,'odczyt(struct node *ww):&#160;funkcje.c']]]
];
