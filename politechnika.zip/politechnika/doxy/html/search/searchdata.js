var indexSectionsWithContent =
{
  0: "_bfhimnoprstuwz",
  1: "n",
  2: "fm",
  3: "bmostuwz",
  4: "himnprtw",
  5: "_n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

