var searchData=
[
  ['h',['h',['../magazyn_8c.html#aa8fd00feef5b2f78895c86e1b440425a',1,'magazyn.c']]]
];
