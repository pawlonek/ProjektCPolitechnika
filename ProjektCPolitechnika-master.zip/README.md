# ProjektCPolitechnika
projekt z programowania w jezyku c, pawel zdrojewski
