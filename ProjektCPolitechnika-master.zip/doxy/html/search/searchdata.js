var indexSectionsWithContent =
{
  0: "n",
  1: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures"
};

