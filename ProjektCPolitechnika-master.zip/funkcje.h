#ifndef fun_h
#define fun_h
 struct node
  {
     char name[29];
     int mark;
     int roll;
     struct node *next;
  };

void testchsum();

void wypisywanie(struct node *start);

void wpisywanie(struct node *g);

void wpisywanie2(struct node *g);

void usun(struct node *gc, int psUsun);

void zmien(struct node *tt);

void zapisdopliku(struct node *gg);

void bubbleSort(struct node *start);

void swap(struct node *a, struct node *b);

void bubbleSortMark(struct node *start);

void bubbleSortName(struct node *start);

void odczyt(struct node *ww);

#endif //fun_h
